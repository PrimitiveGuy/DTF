@echo off
cd /d "%~dp0"
py mockup_generator.py
if errorlevel 1 python mockup_generator.py
