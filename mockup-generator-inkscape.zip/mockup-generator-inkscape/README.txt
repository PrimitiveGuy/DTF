Installing the FreeForge Mockup Generator

The Mockup Generator runs on Windows using Python. You only need to complete these steps the first time.

Step 1: Install Python
Download and install Python 3 from: https://www.python.org/downloads/
Start the Python installer.
Important: On the first installation screen, check the box that says: Add Python to PATH
Continue with the normal installation.
Step 2: Install Pillow

The generator uses a Python image-processing package called Pillow.

Open the Windows Start Menu.
Type cmd.
Open Command Prompt.
Enter:
Plain Text
pip install pillow
Press Enter and allow the installation to finish.

You only need to do this once.

Step 3: Install Inkscape if Using SVG Files

If your designs are PNG, JPG, JPEG, or WEBP files, you can skip this step.

If you want the generator to accept SVG artwork, install Inkscape:

https://inkscape.org/

The Mockup Generator will automatically look for Inkscape when it encounters an SVG design.

Step 4: Set Up the Mockup Generator

Keep the generator files together in one folder.

For example:

Plain Text
FreeForge Mo**up Generator
|
|-- mockup_generat**.py
|-- 09-black.png
|-- README.m**

Your saved settings files may also appear in this folder as you use the program.

Step 5: Start the Generator

If your download includes the launcher we created, simply use that launcher to start the program.

Otherwise, the Python script can be started through Python.

Once it opens, you should see the FreeForge Batch Mockup Generator window.

Creating Your First Mockups
1. Choose Your Shirt Mockup

Click Browse next to Mockup.

Select the blank shirt/model image you want your designs placed onto.

2. Choose Your Designs

Click Browse next to Designs folder.

Select the folder containing your artwork.

The first design will appear in the preview.

3. Position the Design

Use the three sliders:

Scale Multiplier
 Makes the artwork bigger or smaller.

Horizontal Offset
 Moves the artwork left or right.

Vertical Offset
 Moves the artwork up or down.

Adjust these until the design looks right on the shirt.

4. Save Your Default

Once you have positioning that works well for most of your artwork, click:

Save current settings as default

New designs will use that placement unless you tell the program otherwise.

5. Check Your Designs

Use:

Previous | Next

to move through your artwork.

If one particular design doesn't look right, adjust it and click:

Save adjustment for this design

That special adjustment will only apply to that design.

6. Generate the Mockups

When you're ready, click:

GENERATE ALL MOCKUPS

The generator will process your designs and save the finished mockup images into your selected output folder.