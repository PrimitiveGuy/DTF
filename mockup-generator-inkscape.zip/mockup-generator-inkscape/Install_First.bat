@echo off
echo Installing Python image support...
py -m pip install --upgrade pillow
if errorlevel 1 python -m pip install --upgrade pillow

echo.
echo PNG, JPG and WebP are ready after Pillow installs.
echo SVG support uses Inkscape. If Inkscape is already installed, nothing else is needed.
echo The generator automatically checks C:\Program Files\Inkscape\bin.
echo.
pause
