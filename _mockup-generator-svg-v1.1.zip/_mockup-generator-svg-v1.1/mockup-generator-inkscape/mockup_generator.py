import argparse
import json
import os
import sys
import subprocess
import tempfile
import shutil
from pathlib import Path
from PIL import Image

BATCH_MODE = "--batch" in sys.argv
if not BATCH_MODE:
    from PIL import ImageTk
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
else:
    class _DummyTk:
        class Tk:
            pass
    tk = _DummyTk()

APP_TITLE = "FreeForge Batch Mockup Generator"
SUPPORTED = {".png", ".webp", ".jpg", ".jpeg", ".svg"}
DEFAULTS = {
    "shirt_center_x": 627,
    "base_center_y": 480,
    "max_width": 535,
    "max_height": 500,
    "jpg_quality": 94,
    "white_threshold": 248,
}


def has_real_transparency(im):
    return "A" in im.getbands() and im.getchannel("A").getextrema()[0] < 255


def remove_near_white(im, threshold=248):
    im = im.convert("RGBA")
    px = im.load()
    for y in range(im.height):
        for x in range(im.width):
            r, g, b, a = px[x, y]
            if r >= threshold and g >= threshold and b >= threshold:
                px[x, y] = (r, g, b, 0)
    return im


def find_inkscape():
    candidates = [
        shutil.which("inkscape"),
        r"C:\Program Files\Inkscape\bin\inkscape.com",
        r"C:\Program Files\Inkscape\bin\inkscape.exe",
        r"C:\Program Files\Inkscape\inkscape.exe",
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(candidate)
    return None


def open_design(path):
    path = Path(path)
    if path.suffix.lower() != ".svg":
        return Image.open(path)
    inkscape = find_inkscape()
    if not inkscape:
        raise RuntimeError(
            "SVG file found, but Inkscape was not detected. Install Inkscape, then run the generator again. "
            "The generator checks the normal C:\\Program Files\\Inkscape locations automatically."
        )
    temp_dir = Path(tempfile.mkdtemp(prefix="ff_mockup_svg_"))
    png = temp_dir / (path.stem + ".png")
    try:
        cmd = [inkscape, str(path), "--export-type=png", f"--export-filename={png}", "--export-area-drawing", "--export-width=2048"]
        result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=120)
        if result.returncode != 0 or not png.exists():
            raise RuntimeError("Inkscape could not render SVG: " + (result.stderr.strip() or path.name))
        im = Image.open(png).convert("RGBA")
        im.load()
        return im
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def prepare_art(path, threshold=248, auto_remove_white=True):
    original = open_design(path)
    transparent = has_real_transparency(original)
    art = original.convert("RGBA")
    removed_white = False
    if auto_remove_white and not transparent:
        art = remove_near_white(art, threshold)
        removed_white = True
    bbox = art.getchannel("A").getbbox()
    if bbox:
        art = art.crop(bbox)
    return art, transparent, removed_white


def auto_preset(art, transparent, removed_white):
    ratio = art.width / art.height if art.height else 1
    if removed_white and ratio > 1.20:
        return 1.221, 830, "opaque-wide"
    if transparent and ratio > 1.25:
        return 1.221, 830, "transparent-wide"
    if ratio < 0.82:
        return 1.221, 830, "tall"
    return 1.221, 830, "standard"


def compose(mockup, design_path, settings, override=None):
    art, transparent, removed_white = prepare_art(
        design_path,
        settings["white_threshold"],
        settings.get("auto_remove_white", True),
    )
    scale, dy, preset = auto_preset(art, transparent, removed_white)
    dx = 698
    if override:
        scale = float(override.get("scale", scale))
        dx = int(override.get("dx", dx))
        dy = int(override.get("dy", dy))
    fit = min(settings["max_width"] / art.width, settings["max_height"] / art.height) * scale
    nw, nh = max(1, round(art.width * fit)), max(1, round(art.height * fit))
    art = art.resize((nw, nh), Image.Resampling.LANCZOS)
    x = round(settings["shirt_center_x"] - nw / 2 + dx)
    y = round(settings["base_center_y"] - nh / 2 + dy)
    out = mockup.copy().convert("RGBA")
    out.alpha_composite(art, (x, y))
    meta = {"scale": scale, "dx": dx, "dy": dy, "preset": preset, "removed_white": removed_white, "position": [x, y], "size": [nw, nh]}
    return out, meta


def load_overrides(folder):
    p = Path(folder) / "mockup_overrides.json"
    if not p.exists():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_overrides(folder, data):
    Path(folder, "mockup_overrides.json").write_text(json.dumps(data, indent=2), encoding="utf-8")


def defaults_file():
    return Path(__file__).resolve().parent / "mockup_defaults.json"

def load_saved_defaults():
    defaults = {"scale": 1.221, "dx": 698, "dy": 830, "auto_remove_white": True}
    p = defaults_file()
    if p.exists():
        try:
            saved = json.loads(p.read_text(encoding="utf-8"))
            defaults.update(saved)
        except Exception:
            pass
    return defaults

def save_saved_defaults(data):
    defaults_file().write_text(json.dumps(data, indent=2), encoding="utf-8")

def process_batch(mockup_path, design_folder, output_folder, settings, progress=None):
    mockup = Image.open(mockup_path).convert("RGBA")
    files = sorted(p for p in Path(design_folder).iterdir() if p.suffix.lower() in SUPPORTED)
    overrides = load_overrides(design_folder)
    Path(output_folder).mkdir(parents=True, exist_ok=True)
    report = []
    for i, path in enumerate(files, 1):
        override = overrides.get(path.name)
        if override is None:
            d = load_saved_defaults()
            override = {"scale": d["scale"], "dx": d["dx"], "dy": d["dy"]}
        out, meta = compose(mockup, path, settings, override)
        dest = Path(output_folder) / f"{path.stem}_mockup_black.jpg"
        out.convert("RGB").save(dest, quality=settings["jpg_quality"], optimize=True)
        report.append({"source": path.name, "output": dest.name, **meta})
        if progress:
            progress(i, len(files), path.name)
    Path(output_folder, "mockup_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return len(files)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1000x720")
        self.minsize(900, 620)
        here = Path(__file__).resolve().parent
        self.mockup_var = tk.StringVar(value=str(here / "09-black.png"))
        self.design_var = tk.StringVar()
        self.output_var = tk.StringVar()
        saved_defaults = load_saved_defaults()
        self.scale_var = tk.DoubleVar(value=float(saved_defaults.get("scale", 1.221)))
        self.dx_var = tk.IntVar(value=int(saved_defaults.get("dx", 698)))
        self.dy_var = tk.IntVar(value=int(saved_defaults.get("dy", 830)))
        self.remove_white_var = tk.BooleanVar(value=bool(saved_defaults.get("auto_remove_white", True)))
        self.status_var = tk.StringVar(value="Select a designs folder.")
        self.files = []
        self.current = 0
        self.preview_ref = None
        self.meta = None
        self._build()

    def _build(self):
        top = ttk.Frame(self, padding=12); top.pack(fill="x")
        self._path_row(top, "Mockup", self.mockup_var, self.choose_mockup)
        self._path_row(top, "Designs folder", self.design_var, self.choose_designs)
        self._path_row(top, "Output folder", self.output_var, self.choose_output)

        body = ttk.Panedwindow(self, orient="horizontal"); body.pack(fill="both", expand=True, padx=12, pady=6)
        left = ttk.Frame(body, padding=8); right = ttk.Frame(body, padding=8)
        body.add(left, weight=3); body.add(right, weight=2)

        self.preview = ttk.Label(left, anchor="center"); self.preview.pack(fill="both", expand=True)
        nav = ttk.Frame(left); nav.pack(fill="x", pady=8)
        ttk.Button(nav, text="Previous", command=lambda:self.move(-1)).pack(side="left")
        ttk.Button(nav, text="Next", command=lambda:self.move(1)).pack(side="right")
        self.file_label = ttk.Label(nav, text="No design loaded", anchor="center"); self.file_label.pack(side="left", expand=True)

        ttk.Label(right, text="Per-design adjustment", font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(0,8))
        ttk.Label(right, text="Scale multiplier").pack(anchor="w")
        scale_row = ttk.Frame(right); scale_row.pack(fill="x")
        ttk.Scale(scale_row, from_=0.25, to=3.00, variable=self.scale_var, command=lambda _=None:self.refresh()).pack(side="left", fill="x", expand=True)
        ttk.Button(scale_row, text="-", width=3, command=lambda:self.adjust_value("scale", -0.001)).pack(side="left", padx=(6,2))
        ttk.Button(scale_row, text="+", width=3, command=lambda:self.adjust_value("scale", 0.001)).pack(side="left")
        self.scale_entry = ttk.Entry(scale_row, textvariable=self.scale_var, width=8, justify="center")
        self.scale_entry.pack(side="left", padx=(6,0))
        self.scale_entry.bind("<FocusOut>", lambda e:self.apply_entry("scale"))
        self.scale_entry.bind("<Return>", lambda e:self.apply_entry("scale"))
        self.scale_label = ttk.Label(right); self.scale_label.pack(anchor="w")
        ttk.Label(right, text="Horizontal offset (pixels)").pack(anchor="w", pady=(12,0))
        dx_row = ttk.Frame(right); dx_row.pack(fill="x")
        ttk.Scale(dx_row, from_=-1000, to=1500, command=self.on_dx_slider).pack(side="left", fill="x", expand=True)
        ttk.Button(dx_row, text="-", width=3, command=lambda:self.adjust_value("dx", -1)).pack(side="left", padx=(6,2))
        ttk.Button(dx_row, text="+", width=3, command=lambda:self.adjust_value("dx", 1)).pack(side="left")
        self.dx_entry = ttk.Entry(dx_row, textvariable=self.dx_var, width=8, justify="center")
        self.dx_entry.pack(side="left", padx=(6,0))
        self.dx_entry.bind("<FocusOut>", lambda e:self.apply_entry("dx"))
        self.dx_entry.bind("<Return>", lambda e:self.apply_entry("dx"))
        self.dx_label = ttk.Label(right); self.dx_label.pack(anchor="w")
        ttk.Label(right, text="Vertical offset (pixels)").pack(anchor="w", pady=(12,0))
        dy_row = ttk.Frame(right); dy_row.pack(fill="x")
        ttk.Scale(dy_row, from_=-1000, to=2000, command=self.on_dy_slider).pack(side="left", fill="x", expand=True)
        ttk.Button(dy_row, text="-", width=3, command=lambda:self.adjust_value("dy", -1)).pack(side="left", padx=(6,2))
        ttk.Button(dy_row, text="+", width=3, command=lambda:self.adjust_value("dy", 1)).pack(side="left")
        self.dy_entry = ttk.Entry(dy_row, textvariable=self.dy_var, width=8, justify="center")
        self.dy_entry.pack(side="left", padx=(6,0))
        self.dy_entry.bind("<FocusOut>", lambda e:self.apply_entry("dy"))
        self.dy_entry.bind("<Return>", lambda e:self.apply_entry("dy"))
        self.dy_label = ttk.Label(right); self.dy_label.pack(anchor="w")
        ttk.Checkbutton(right, text="Automatically remove near-white background from opaque images", variable=self.remove_white_var, command=self.refresh).pack(anchor="w", pady=12)
        ttk.Button(right, text="Save adjustment for this design", command=self.save_current).pack(fill="x", pady=4)
        ttk.Button(right, text="Save current settings as default", command=self.save_as_default).pack(fill="x", pady=4)
        ttk.Button(right, text="Reset this design to automatic", command=self.reset_current).pack(fill="x", pady=4)
        ttk.Separator(right).pack(fill="x", pady=16)
        ttk.Button(right, text="GENERATE ALL MOCKUPS", command=self.generate).pack(fill="x", ipady=8)
        self.progress = ttk.Progressbar(right, mode="determinate"); self.progress.pack(fill="x", pady=10)
        ttk.Label(right, textvariable=self.status_var, wraplength=320).pack(anchor="w")

    def _path_row(self, parent, label, var, command):
        row=ttk.Frame(parent); row.pack(fill="x", pady=3)
        ttk.Label(row,text=label,width=14).pack(side="left")
        ttk.Entry(row,textvariable=var).pack(side="left",fill="x",expand=True,padx=6)
        ttk.Button(row,text="Browse",command=command).pack(side="right")

    def choose_mockup(self):
        p=filedialog.askopenfilename(filetypes=[("Images","*.png *.jpg *.jpeg")]);
        if p: self.mockup_var.set(p); self.refresh()
    def choose_designs(self):
        p=filedialog.askdirectory()
        if p:
            self.design_var.set(p); self.output_var.set(str(Path(p)/"mockups")); self.load_files()
    def choose_output(self):
        p=filedialog.askdirectory()
        if p: self.output_var.set(p)
    def load_files(self):
        d=Path(self.design_var.get()); self.files=sorted(p for p in d.iterdir() if p.suffix.lower() in SUPPORTED) if d.exists() else []
        self.current=0; self.load_current()
    def move(self, n):
        if not self.files:return
        self.current=(self.current+n)%len(self.files); self.load_current()
    def load_current(self):
        if not self.files:return
        path=self.files[self.current]; overrides=load_overrides(self.design_var.get())
        mock=Image.open(self.mockup_var.get()).convert("RGBA")
        override = overrides.get(path.name)
        if override is None:
            d = load_saved_defaults()
            override = {"scale": d["scale"], "dx": d["dx"], "dy": d["dy"]}
            self.remove_white_var.set(bool(d.get("auto_remove_white", True)))
        settings=self.settings()
        _,meta=compose(mock,path,settings,override)
        self.scale_var.set(meta["scale"]); self.dx_var.set(meta.get("dx",0)); self.dy_var.set(meta["dy"]); self.refresh()
    def on_dx_slider(self, value):
        self.dx_var.set(int(round(float(value))))
        self.refresh()

    def on_dy_slider(self, value):
        self.dy_var.set(int(round(float(value))))
        self.refresh()

    def apply_entry(self, control):
        try:
            if control == "scale":
                value = min(3.00, max(0.25, float(self.scale_var.get())))
                self.scale_var.set(round(value, 3))
            elif control == "dx":
                value = min(1500, max(-1000, int(round(float(self.dx_var.get())))))
                self.dx_var.set(value)
            elif control == "dy":
                value = min(2000, max(-1000, int(round(float(self.dy_var.get())))))
                self.dy_var.set(value)
            self.refresh()
        except (ValueError, tk.TclError):
            self.load_current()

    def adjust_value(self, control, amount):
        if control == "scale":
            value = min(3.00, max(0.25, self.scale_var.get() + amount))
            self.scale_var.set(round(value, 3))
        elif control == "dx":
            value = min(1500, max(-1000, round(self.dx_var.get()) + amount))
            self.dx_var.set(int(value))
        elif control == "dy":
            value = min(2000, max(-1000, round(self.dy_var.get()) + amount))
            self.dy_var.set(int(value))
        self.refresh()

    def settings(self):
        return {**DEFAULTS,"auto_remove_white":self.remove_white_var.get()}
    def refresh(self):
        if not self.files or not Path(self.mockup_var.get()).exists():return
        path=self.files[self.current]; mock=Image.open(self.mockup_var.get()).convert("RGBA")
        override={"scale":round(self.scale_var.get(),3),"dx":round(self.dx_var.get()),"dy":round(self.dy_var.get())}
        out,self.meta=compose(mock,path,self.settings(),override)
        prev=out.copy(); prev.thumbnail((610,520),Image.Resampling.LANCZOS)
        self.preview_ref=ImageTk.PhotoImage(prev); self.preview.configure(image=self.preview_ref)
        self.file_label.configure(text=f"{self.current+1} of {len(self.files)}  |  {path.name}")
        self.scale_label.configure(text=f"{self.scale_var.get():.3f}")
        self.dx_label.configure(text=f"{round(self.dx_var.get())} px")
        self.dy_label.configure(text=f"{round(self.dy_var.get())} px")
        self.status_var.set(f"Preset: {self.meta['preset']} | White removed: {self.meta['removed_white']}")
    def save_current(self):
        if not self.files:return
        data=load_overrides(self.design_var.get()); data[self.files[self.current].name]={"scale":round(self.scale_var.get(),3),"dx":round(self.dx_var.get()),"dy":round(self.dy_var.get())}
        save_overrides(self.design_var.get(),data); self.status_var.set("Adjustment saved.")
    def save_as_default(self):
        # Snapshot the slider values first. This includes SCALE exactly as displayed.
        data = {
            "scale": float(f"{self.scale_var.get():.3f}"),
            "dx": int(round(self.dx_var.get())),
            "dy": int(round(self.dy_var.get())),
            "auto_remove_white": bool(self.remove_white_var.get()),
        }
        save_saved_defaults(data)

        # If this design already had an older per-design override, it would take
        # priority over the new defaults when the design is loaded again. Remove
        # that stale override so the newly-saved defaults visibly take effect.
        if self.files and self.design_var.get():
            overrides = load_overrides(self.design_var.get())
            overrides.pop(self.files[self.current].name, None)
            save_overrides(self.design_var.get(), overrides)

        # Re-apply the saved values to the controls to make the saved state explicit.
        self.scale_var.set(data["scale"])
        self.dx_var.set(data["dx"])
        self.dy_var.set(data["dy"])
        self.remove_white_var.set(data["auto_remove_white"])
        self.refresh()
        self.status_var.set(
            f'Default saved: scale {data["scale"]:.3f}, X {data["dx"]} px, Y {data["dy"]} px.'
        )

    def reset_current(self):
        if not self.files:return
        data=load_overrides(self.design_var.get()); data.pop(self.files[self.current].name,None); save_overrides(self.design_var.get(),data); self.load_current()
    def generate(self):
        if not self.files or not self.output_var.get():
            messagebox.showerror(APP_TITLE,"Select a designs folder and output folder first.");return
        self.save_current()
        def prog(i,total,name):
            self.progress["maximum"]=total;self.progress["value"]=i;self.status_var.set(f"{i}/{total}: {name}");self.update_idletasks()
        try:
            n=process_batch(self.mockup_var.get(),self.design_var.get(),self.output_var.get(),self.settings(),prog)
            messagebox.showinfo(APP_TITLE,f"Finished generating {n} mockups.\n\nOutput: {self.output_var.get()}")
        except Exception as e:
            messagebox.showerror(APP_TITLE,str(e))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--batch",action="store_true")
    parser.add_argument("--mockup",default=str(Path(__file__).resolve().parent/"09-black.png"))
    parser.add_argument("--designs")
    parser.add_argument("--output")
    args=parser.parse_args()
    if args.batch:
        if not args.designs or not args.output: parser.error("--designs and --output are required with --batch")
        n=process_batch(args.mockup,args.designs,args.output,{**DEFAULTS,"auto_remove_white":True})
        print(f"Generated {n} mockups in {args.output}")
    else:
        App().mainloop()

if __name__=="__main__": main()
